import "./footer.css";
import React from "react";

function template() {
  return (
    <div className="footer">
      <div className="container text-center p-4 bg-info">
        <div className="row m-4">
          <div className="col-md-4">ashish</div>
          <div className="col-md-4">ashish</div>
          <div className="col-md-4">ashish</div>
        </div>
        <div className="row m-4">
          <div className="col-md-4">ashish</div>
          <div className="col-md-4">ashish</div>
          <div className="col-md-4">ashish</div>
        </div>
        <div className="row m-4">
          <div className="col-md-4">ashish</div>
          <div className="col-md-4">ashish</div>
          <div className="col-md-4">ashish</div>
        </div>
      </div>
    </div>
  );
};

export default template;
