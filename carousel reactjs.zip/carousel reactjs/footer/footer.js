import React    from "react";
import template from "./footer.jsx";

class footer extends React.Component {
  render() {
    return template.call(this);
  }
}

export default footer;
