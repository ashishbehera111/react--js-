import "./content.css";
import React from "react";
import PIC from"./photo/article_mobile.jpg" 
import PIC1 from "./photo/pic1.jpeg"
import PIC2 from "./photo/picture.jpeg"

function template() {
  return (
    <div className="content">
        <div className="container">
<div className="row text-center text-white bg-dark p-4">
  <div className="col-md-4">
    <h3 >hii Welcome to React js</h3>
  </div>
  <div className="col-md-4">
    <h3 >hii Welcome to React js</h3>
  </div>
  <div className="col-md-4">
    <h3 >hii Welcome to React js</h3>
  </div>
</div>
      </div>
      <div className="container">
<div className="row text-center text-white bg-dark p-4">
  <div className="col-md-4">
    <img src={PIC} width="200" height="200" />
  </div>
  <div className="col-md-4">
    
    <img src={PIC1} width="200" height="200" />
  </div>
  <div className="col-md-4">
    
    <img src={PIC2} width="200" height="200" />
  </div>
</div>
      </div>
    </div>
  );
};

export default template;
