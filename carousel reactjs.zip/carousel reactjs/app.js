import React,{Component} from "react"
import HEADER from "./header"
import CAROUSEL from "./carousel"
import CONTENT from "./content"
import FOOTER from "./footer"
import "mdbootstrap/css/bootstrap.min.css"
import "jquery/dist/jquery.min.js"

class cl1 extends Component{
    render(){
        return(
            <div>
<HEADER/>
<CAROUSEL/>
<CONTENT/>
<FOOTER/>
            </div>
        )
    }
}
export default cl1