import "./header.css";
import React from "react";

function template() {
  return (
    <div className="header">
      <div className="container">
<div className="row text-center text-primary bg-success p-4">
  <div className="col-md-12">
    <h3 >hii Welcome to React js</h3>
  </div>
</div>
      </div>
    </div>
  );
};

export default template;
