import React,{Component} from "react";

class cls1 extends Component{
    sno=100;
    state={
        sn:555
    }
    fun1=()=>{
        this.sno=4567;
        this.state.sn=666
        alert(this.sno)
        this.setState({
            sn:777,
            sno:8889,
        })
    }
    render(){
        return (
            <div>
                welcome-{this.sno} - {this.state.sn}
                <input type="button" value="click" onClick={this.fun1}/>
            </div>
        )
    }
}
export default cls1;