import React ,{Component} from "react"

class cls1 extends Component{
    state={
        txt1:"scott"
    }
    fun2(t){
        this.setState.txt1=t.target.value
        this.setState({})
    }
    render(){
        return(
            <div>
                {this.setState.txt1}
                <br></br>
                <input type="text" onKeyUp={this.fun2.bind(this)}/>
            </div>
        )
    }
}
export default cls1;