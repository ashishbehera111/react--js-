import React,{Component} from 'react'

class ash extends Component{
  render(){
    return(
      <div>
        <p>hii im ashish and i am a softwere enger...</p>
      </div>
    )
  }
}
export default ash;