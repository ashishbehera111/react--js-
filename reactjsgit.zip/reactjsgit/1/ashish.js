import React,{Component} from 'react';

class ask1 extends Component{
    render(){
        return (
            <div>
                <p>my name is ashish </p>
                <p>i am react developer</p>
            </div>
        )      
    }
}
export default ask1;