import React    from "react";
class content extends React.Component {
  state={
   tmp:100,
   city:'hyderabad'
  }
  fun1=()=>{
    //alert(this.state.city)
    var str="http://api.openweathermap.org/data/2.5/weather?q="+
    this.state.city+"&units=metric&appid=864454684e0c56c960ac9555ac00425c"
    alert(str)
    fetch(str)
    .then(res=>res.json()).then((dt)=>{
      console.log(dt)
      this.setState({
        tmp:dt.main.temp
      })
    })
  }
  funcng=(e)=>{
    this.setState({
      city:e.target.value
    })
  }
  render() {
    //return template.call(this);
    return (
      <div>
        <input type="text" value={this.state.city} onChange={this.funcng.bind(this)}></input>
        <input type="button" value="Get" onClick={this.fun1}></input><br></br>
        {this.state.tmp}
      </div>
    )
  }
}
export default content;