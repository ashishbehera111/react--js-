import "./footer.css";
import React from "react";

function template() {
  return (
    <div className="footer">
      <h1>footer</h1>
    </div>
  );
};

export default template;
