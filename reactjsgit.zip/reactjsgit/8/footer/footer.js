import React    from "react";
import template from "./footer.jsx";
import photo from "../photo/pic1.jpeg"
import pic from "./photo/picture.jpeg"

class footer extends React.Component {
  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-md-6">
<img src={photo} width="300"/>
          </div>
          <div className="col-md-6">
<img src={pic} width="300"/>
          </div>
          </div> 
      <div className="three">
        footer
      </div>
      </div>
    )
  }
}

export default footer;
