import content from "./content";
export default content;
