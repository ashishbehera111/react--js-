import "./content.css";
import React from "react";

function template() {
  return (
    <div className="content">
      <h1>content</h1>
    </div>
  );
};

export default template;
