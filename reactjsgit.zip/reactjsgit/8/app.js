import React,{Component} from "react";
import HEADER from "./header";
import FOOTER from "./footer";
import CONTENT from "./content"
import "bootstrap/dist/css/bootstrap.min.css"
import  "font-awesome/css/font-awesome.css"

class cls1 extends Component{
   
    render(){
        return (
          <div>
           <HEADER/>
           <CONTENT/>
           <FOOTER/>
           
           </div>
            )
    }
}

export default cls1;