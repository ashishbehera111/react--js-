import "./header.css";
import React from "react";


function template() {
  return (
    <div className="header">
      <h1>header</h1>
      <button type="button" className="btn btn-success">hiii</button>
      <button className="btn btn-primary"></button>
    </div>
  );
};

export default template;
