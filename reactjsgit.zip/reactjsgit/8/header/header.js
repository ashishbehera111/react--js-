import React    from "react";
import template from "./header.jsx";
import "./header.css"
import "bootstrap/dist/css/bootstrap.min.css"

class header extends React.Component {
  render() {
    return (
     <div className="container">
       <div className="row"> 
<div className="col-md-12"><p className="text-danger text-center bg-dark p-4">welcome to React js</p></div>
       </div>
     </div>
    )
  }
  
}

export default header;
