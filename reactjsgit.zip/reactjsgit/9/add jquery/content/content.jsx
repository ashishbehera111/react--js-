import "./content.css";
import React from "react";
import f1 from "../photo/slider1.jpg"
import $ from "jquery"
function template() {
  function fun1(){
    $("img").slideUp(2000).delay(5000).fadeIn(2000)
  }
  return (
  <div className="two">
    <p>container</p>
    <br/>
    <input type="button" value="hide" onClick={fun1}/>
    <br/>
    <img src={f1} style={{width:"200px"}} id="img"/>
</div>   
  );
};

export default template;
