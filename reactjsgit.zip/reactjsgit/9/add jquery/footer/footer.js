import React    from "react";
import template from "./footer.jsx";
import photo from "../photo/pic1.jpeg"
import pic from "./photo/picture.jpeg"

class footer extends React.Component {
  render() {
    return template.call(this);
  }

}
export default footer;
