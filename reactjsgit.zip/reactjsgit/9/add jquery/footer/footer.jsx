import "./footer.css";
import React from "react";

function template() {
  return (
    <div className="three">
      
    </div>
  );
};

export default template;
