import "./header.css";
import React from "react";


function template() {
  return (
    <div className="container">
       <div className="row"> 
<div className="col-md-12"><p className="text-danger text-center bg-dark p-4">welcome to React js</p></div>
       </div>
     </div>
  );
};

export default template;
