import React    from "react";
import template from "./header.jsx";
import "./header.css"
import "bootstrap/dist/css/bootstrap.min.css"

class header extends React.Component {
  render() {
    return template.call(this) 
     
    
  }
  
}

export default header;
