import React    from "react";
import template from "./contact.jsx";

class contact extends React.Component {
  render() {
    return template.call(this);
  }
}

export default contact;
