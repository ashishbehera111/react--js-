import contact from "./contact";
export default contact;
