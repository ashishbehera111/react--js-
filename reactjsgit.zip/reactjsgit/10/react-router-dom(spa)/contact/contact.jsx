import "./contact.css";
import React from "react";

function template() {
  return (
    <div className="contact">
      <h1>contact</h1>
    </div>
  );
};

export default template;
