import React,{Component} from "react";


class cls1 extends Component{
   
    render(){
        return (
          <div>
      <h1>hiii</h1>
           </div>
            )
    }
}

export default cls1;