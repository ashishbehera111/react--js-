import "./aboutus.css";
import React from "react";

function template() {
  return (
    <div className="aboutus">
      <h1>aboutus</h1>
    </div>
  );
};

export default template;
