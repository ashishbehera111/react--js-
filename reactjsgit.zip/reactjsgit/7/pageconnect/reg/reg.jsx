import "./reg.css";
import React from "react";

function template() {
  return (
    <div className="reg">
      <h1>reg</h1>
    </div>
  );
};

export default template;
