import reg from "./reg";
export default reg;
