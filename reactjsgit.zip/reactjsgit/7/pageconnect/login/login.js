import React    from "react";
import template from "./login.jsx";

class login extends React.Component {
  render() {
    return (
      <div >
        
        <div className="form-group">
          <input type="text" placeholder="username"  class="form-control text-center"></input>
          <br/>
          <input type="password" placeholder="password"  class="form-control text-center"></input>
          </div>
        
      </div>
    );
  }
}

export default login;
