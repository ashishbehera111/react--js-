import "./login.css";
import React from "react";

function template() {
  return (
    <div className="login">
      <h1>login</h1>
    </div>
  );
};

export default template;
