import React,{Component} from "react";
import PIC from "./photo/article_mobile.jpg"
import Pho from "./photo/pic1.jpeg"
import PIC2 from "./photo/picture.jpeg"
class cls1 extends Component{
  
    render(){
        return (

           <div className="container">
                  <div className="row">
                      <div className="col-md-3 bg-success">
                          <p>lorem20ashish kumar Notice the use of %PUBLIC_URL% in the tags above.
      It will be replaced with the URL of the `public` folder during the build.
      Only files inside the `public` folder can be referenced from the HTML.

      Unlike "/favicon.ico" or "favicon.ico", "%PUBLIC_URL%/favicon.ico" will
      work correctly both with client-side routing and a non-root public URL.
      Learn how to configure a non-root public URL by running `npm run build`.</p>
                          </div> 
                          <div className="col-md-3 bg-primary">
                          <p>lorem20ashish kumar Notice the use of %PUBLIC_URL% in the tags above.
      It will be replaced with the URL of the `public` folder during the build.
      Only files inside the `public` folder can be referenced from the HTML.

      Unlike "/favicon.ico" or "favicon.ico", "%PUBLIC_URL%/favicon.ico" will
      work correctly both with client-side routing and a non-root public URL.
      Learn how to configure a non-root public URL by running `npm run build`.</p>
                          </div> 
                          <div className="col-md-3 bg-secondary">
                          <p>lorem20ashish kuma Notice the use of %PUBLIC_URL% in the tags above.
      It will be replaced with the URL of the `public` folder during the build.
      Only files inside the `public` folder can be referenced from the HTML.

      Unlike "/favicon.ico" or "favicon.ico", "%PUBLIC_URL%/favicon.ico" will
      work correctly both with client-side routing and a non-root public URL.
      Learn how to configure a non-root public URL by running `npm run build`.r</p>
                          </div> 
                          <div className="col-md-3 bg-danger">
                          <p>lorem20ashish kumar Notice the use of %PUBLIC_URL% in the tags above.
      It will be replaced with the URL of the `public` folder during the build.
      Only files inside the `public` folder can be referenced from the HTML.

      Unlike "/favicon.ico" or "favicon.ico", "%PUBLIC_URL%/favicon.ico" will
      work correctly both with client-side routing and a non-root public URL.
      Learn how to configure a non-root public URL by running `npm run build`.</p>
                          </div> 
                      </div>
                      <div className="container ">
                          <div className="row">
                         <div className="col-md-6">
<img src={PIC}  height="200"/>
                         </div>
                         <div className="col-md-6">
<img src={Pho}  height="200"/>
                         </div>
                          </div>
                          </div>
                          <div className="container">
<table className="table table-bordered text-center table-hover">
    <thead className="bg-success">
        <tr>
            <th>name</th>
            <th>roll</th>
            <th>class</th>
        </tr>
    </thead>
    <tbody>
        <tr>
        
            <th>name</th>
            <th>roll</th>
            <th>class</th>
        
        
        </tr>
        <tr>
            <th>name</th>
            <th>roll</th>
            <th>class</th>
        </tr>
    </tbody>
</table>
                          </div>
           </div>
         
       
            )
    }
}

export default cls1;