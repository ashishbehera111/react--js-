import "./logout.css";
import React from "react";

function template() {
  return (
    <div className="logout">
      <h1>logout</h1>
    </div>
  );
};

export default template;
