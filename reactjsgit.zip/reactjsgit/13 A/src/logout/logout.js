import React    from "react";
import template from "./logout.jsx";

class logout extends React.Component {
  constructor(){
    super()
localStorage.removeItem("scott")
  }
  render() {
    return template.call(this);
  }
}

export default logout;
