import React from 'react';
import ReactDOM from 'react-dom';
import {Route,Link,BrowserRouter as Brout} from "react-router-dom"
import {GuardProvider,GuardedRoute} from "react-router-guards"
import Home from "./home/home"
import Help from "./help/help"
import Services from "./services/services"
import Bookings from "./bookings/bookings"
import Logout from "./logout/logout"
import Login from "./login/login"
const gaser=(x,y,next)=>{
  if(localStorage.getItem("scott"))
  {
      next()
  }
  else
  next.redirect("/login")
}
const obj=(
    <Brout>
      <Link to="/hm">Home</Link>
      <Link to="/he">Help</Link>
      <Link to="/se">Services</Link>
      <Link to="/bo">Bookings</Link>
      <Link to="/logout">Logout</Link>
      <br></br>
      <Route exact path="/" component={Home}/>
      <GuardProvider>
      <GuardedRoute path="/hm" component={Home} />
      <GuardedRoute path="/he" component={Help} />
      <GuardedRoute path="/logout" component={Logout} />
      <GuardedRoute path="/login" component={Login} />
      </GuardProvider>

      <GuardProvider guards={gaser}>
      <GuardedRoute path="/se" component={Services} />
      <GuardedRoute path="/bo" component={Bookings} />
      </GuardProvider>
    </Brout>
)
ReactDOM.render(obj , document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA

