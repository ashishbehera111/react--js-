import "./home.css";
import React from "react";

function template() {
  return (
    <div className="home">
      <h1>home</h1>
    </div>
  );
};

export default template;
