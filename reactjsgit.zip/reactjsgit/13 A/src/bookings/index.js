import bookings from "./bookings";
export default bookings;
