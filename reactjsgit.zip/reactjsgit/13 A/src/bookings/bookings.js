import React    from "react";
import template from "./bookings.jsx";

class bookings extends React.Component {
  render() {
    return template.call(this);
  }
}

export default bookings;
