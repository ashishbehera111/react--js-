import "./bookings.css";
import React from "react";

function template() {
  return (
    <div className="bookings">
      <h1>bookings</h1>
    </div>
  );
};

export default template;
