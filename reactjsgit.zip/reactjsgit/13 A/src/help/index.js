import help from "./help";
export default help;
