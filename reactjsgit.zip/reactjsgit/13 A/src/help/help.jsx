import "./help.css";
import React from "react";

function template() {
  return (
    <div className="help">
      <h1>help</h1>
    </div>
  );
};

export default template;
