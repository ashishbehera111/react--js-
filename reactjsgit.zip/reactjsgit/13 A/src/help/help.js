import React    from "react";
import template from "./help.jsx";

class help extends React.Component {
  render() {
    return template.call(this);
  }
}

export default help;
