import "./login.css";
import React from "react";

class template extends React.Component {
  state={
    uname:"",
    pwd:""
  }
  chk
  funUser=(t)=>{
   this.setState({
     uname:t.target.value
   })
  }
  funpwd=(t)=>{
    this.setState({
      pwd:t.target.value
    })
   }
   funcheck=(t)=>{
    this.chk=t.target.checked
   
   }
   funlogin=()=>{
      if(this.chk==true){
      localStorage.setItem(this.state.uname,
        this.state.pwd)
    }
   }
   funuserpwd=(t)=>{
    let str = localStorage.getItem(t.target.value)
    this.setState({
      pwd:str
    })
   }
   
  render(){
      return (
        <div className="login">
        <input type="text"  
          onChange={this.funUser.bind(this)}
          onBlur={this.funuserpwd.bind(this)}></input>
          <br/><br/>
        <input type="text"  value={this.state.pwd}
          onChange={this.funpwd.bind(this)}></input>
          <br/><br/>
        <input type="checkbox" 
        onChange={this.funcheck.bind(this)}></input>
        <br/>
        <input type="button" value="login" 
        onClick={this.funlogin}></input>
        </div>
              );
  }
};

export default template;
