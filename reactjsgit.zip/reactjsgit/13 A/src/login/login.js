import React    from "react";
import Template from "./login.jsx";

class login extends React.Component {
  render() {
    return (
      <div>
       <Template/>
      </div>
    )
  }
}

export default login;
