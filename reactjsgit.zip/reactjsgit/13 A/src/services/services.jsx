import "./services.css";
import React from "react";

function template() {
  return (
    <div className="services">
      <h1>services</h1>
    </div>
  );
};

export default template;
