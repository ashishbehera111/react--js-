import React    from "react";
import template from "./services.jsx";

class services extends React.Component {
  render() {
    return template.call(this);
  }
}

export default services;
