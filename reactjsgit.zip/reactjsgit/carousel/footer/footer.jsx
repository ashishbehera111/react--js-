import "./footer.css";
import React from "react";

function template() {
  return (
    <div className="container bg-success " style={{height:"200px"}}>
      <h1>footer</h1>
    </div>
  );
};

export default template;
