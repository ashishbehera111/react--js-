import React,{Component} from "react";
import HEADER from "./header"
import CAROUSEL from "./carousel"
import  CONTENT from "./content"
import FOOTER from "./footer"
import "bootstrap/dist/css/bootstrap.min.css"
import  "font-awesome/css/font-awesome.css"
import "jquery/dist/jquery.min.js"

class cls1 extends Component{
   
    render(){
        return (
          <div>
       <HEADER/>
       <CAROUSEL/>
       <CONTENT/>
       <FOOTER/>
           </div>
            )
    }
}

export default cls1;