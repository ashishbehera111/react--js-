import "./carousel.css";
import React from "react";
import pic from "../photo/slider2.jpg" 
import pic2 from "../photo/slider1.jpg"
import pic3 from "../photo/slider3.jpg"
import $ from "jquery"
function template() {
  function f1(){

 
  $('.carousel').carousel({
    interval:2000,
    pause:'hover'
});
}
  return (
    <div class="container bg-primary " style={{height:"300px"}}>
       <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src={pic} class="d-block w-100 " style={{height:"300px",width:"700px"}} alt="..."/>
            </div>
            <div class="carousel-item">
                <img src={pic2} class="d-block w-100" style={{height:"300px"}}alt="..."/>
            </div>
            <div class="carousel-item">
                <img src={pic3} class="d-block w-100"style={{height:"300px"}} alt="..."/>
            </div>
        </div>
    </div>
    </div>
  );
};

export default template;
