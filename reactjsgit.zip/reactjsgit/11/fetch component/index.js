import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './app';
import ABOUTUS from "./aboutus"
import CONTACTUS from "./contact"
//import * as serviceWorker from './serviceWorker';
import {Route,Link,BrowserRouter as Router} from "react-router-dom"
const robj=(
    <Router>
        <div>
            <nav>
            <ul>
                <li><Link to="/hm">Home</Link></li>
                <li><Link to="/ab">Aboutus</Link></li>
                <li><Link to="/cn">contact</Link></li>
            </ul>
            </nav>
            <br></br>
            <Route exact path="/" component={App}/>
            <Route  path="/hm" component={App}/>
            <Route  path="/ab" component={ABOUTUS}/>
            <Route  path="/cn" component={CONTACTUS}/>
        </div>
    </Router>
)
ReactDOM.render(robj, document.getElementById('root'));


//serviceWorker.unregister();
