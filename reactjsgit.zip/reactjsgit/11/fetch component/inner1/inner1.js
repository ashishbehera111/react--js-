import React    from "react";
import template from "./inner1.jsx";

class inner1 extends React.Component {
  render() {
    return template.call(this);
  }
}

export default inner1;
