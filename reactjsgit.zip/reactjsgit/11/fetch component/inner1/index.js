import inner1 from "./inner1";
export default inner1;
