import "./inner1.css";
import React from "react";

function template() {
  return (
    <div className="inner-1">
      <h1>inner1111</h1>
    </div>
  );
};

export default template;
