import "./contact.css";
import React from "react";
import INNER1 from "../inner1"
import INNER2 from "../inner2"
import {Route,Link,BrowserRouter as RT} from "react-router-dom"
function template() {
  const robj=(
    <RT>
      <ul>
        <li><Link to="/inn1">openInner</Link></li>
        <li><Link to="/inn2">openInner</Link></li>
      </ul>
      <br></br>
      <div style={{backgroundColor:"lightblue"}}>
      <Route  path="/inn1" component={INNER1}/>
            <Route  path="/inn2" component={INNER2}/>
      </div>
    </RT>
  )
  return (
    <div className="contact">
      <h1>contact</h1>
      {robj}
    </div>
  );
};

export default template;
