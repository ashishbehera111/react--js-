import inner2 from "./inner2";
export default inner2;
