import "./inner2.css";
import React from "react";

function template() {
  return (
    <div className="inner-2">
      <h1>inner2</h1>
    </div>
  );
};

export default template;
