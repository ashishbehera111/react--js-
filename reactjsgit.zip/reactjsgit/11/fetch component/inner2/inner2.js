import React    from "react";
import template from "./inner2.jsx";

class inner2 extends React.Component {
  render() {
    return template.call(this);
  }
}

export default inner2;
