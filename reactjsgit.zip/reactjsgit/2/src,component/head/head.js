import React ,{Component} from "react";
import "./head.css"
class clshead extends Component{
    render(){
        return (
            <div className="header">
                header
            </div>
        )
    }
}
export default clshead;