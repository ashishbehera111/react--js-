import React , {Component} from "react";
import Content from "./content/content"
import Head from "./head/head";
import Left from "./left/left";
import Footer from "./footer/footer"

class clshome extends Component{
    render(){
        return(
            <div>
    <Head/>
    <Left/>
    <Content/>
    <Footer/>
    </div>        

)
    }
}
export default clshome;