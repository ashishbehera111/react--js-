import React,{Component} from "react";
import "./content.css"
class cls extends Component{
    render(){
        return (
            <div className="cont">
                ashish kumar 
            </div>
        )
    }
}
export default cls;