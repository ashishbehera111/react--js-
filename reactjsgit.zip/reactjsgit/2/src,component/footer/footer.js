import React, {Component} from "react";
import "./footer.css"
class footer1 extends Component{
    render(){
        return (
            <div className="footer">
             footer
                </div>
        )
    }
}
export default footer1;