import React, {Component} from "react";
import "./left.css"
class left1 extends Component{
    render(){
        return (
            <div className="aside">
                left
            </div>
        )
    }
}
export default left1;