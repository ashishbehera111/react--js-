import React from "react";

class cls1 extends React.Component{
   t1;t2;refs
   fun1(t){
       this.t1=t.target.value
   }
   fun2=(t)=>{
       this.t2=t.target.value
   }
   funadd=(t)=>{
       this.res=parseInt(this.t1)+parseInt(this.t2)
       this.setState({})
   }
   funmul=(t)=>{
       this.res=(this.t1)*(this.t2)
       this.setState({})
   }
   render(){
       return(
           <div>
               <input type="text" value={this.t1} placeholder="enter number" onChange={this.fun1.bind(this)}></input> 
               <br></br>
               <input type="text" value={this.t2} placeholder="enter number" onChange={this.fun2.bind(this)}></input>
           <br></br>
           <input type="text" value={this.res}></input>
           <br></br>
           <input type="button" value="*" onClick={this.funmul} > 
           
           </input>
           <input type="button" value="+" onClick={this.funadd}>
           
           </input>

           </div>
       )
   }
}
export default cls1;