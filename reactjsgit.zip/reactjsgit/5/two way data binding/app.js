import React from "react";

class cls1 extends React.Component{
    t1="scott"
    fun1(t){
        this.t1=(t.target.value)
        this.setState({})
    }
    render(){
        return(
            <div>
    <h2>{this.t1}</h2>
    <input type="text" value={this.t1} onChange={this.fun1.bind(this)}/>
    welcome
            </div>
        )
    }
}
export default cls1;