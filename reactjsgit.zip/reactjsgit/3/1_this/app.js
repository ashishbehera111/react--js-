import React,{Component} from "react";
class cls1 extends Component{
    fun1=()=>{
        alert("execute function")
    }
    render(){
        return(
            <div>
<input type="button" value="button" onClick={this.fun1}/>   
            </div>
        )
    }
}
export default cls1;