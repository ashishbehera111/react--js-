import React from "react";

var sol=(props)=>{
    return(
        <div>
  hiii my name is {props.name}
  
   ,i am from {props.name1}
        </div>
    )
}
export  default sol ;