import React from "react";
import "./index.css"
import Child from "./child";

var sad=()=>{
    return(
        <div className="text">
            hiii
            <Child name="ashish" name1="odisha"/>
        </div>
    )
}
export default sad;