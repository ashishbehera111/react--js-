import React,{Component} from "react";
class cls1 extends Component{
   fun1=(x,y)=>{
alert(this)
alert(x)
alert(y)
   }
    render(){
        return(
            <div>
<input type="button" value="button" onClick={this.fun1.bind(this,100,200)}/>   
            </div>
        )
    }
}
export default cls1;