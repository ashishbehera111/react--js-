import React,{Component} from "react";
class cls1 extends Component{
    sno=1234
   fun1=(x,y)=>{
    var  sno=444
    alert(this.sno)
    alert(sno)
    alert(x)
    alert(y)

   }
    render(){
        return(
            <div>
                <input type="text" value={this.sno}/>
<input type="button" value="button" onClick={this.fun1.bind(this,100,200)}/>   
            </div>
        )
    }
}
export default cls1;