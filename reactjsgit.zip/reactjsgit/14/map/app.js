import React from "react";

class cls1 extends React.Component{
  state={
      arr:[10,20,30,40,"abcd"]
  }
   render(){
    var data=null
    data=this.state.arr.map((val,ind)=>{
    return <h1>{val}--{ind}</h1>
    })
       return(
           <div>
             {data}

           </div>
       )
   }
}
export default cls1;