import React from "react";

class cls1 extends React.Component{
  state={
      obj:[
          {uname:"scott",city:"hyd"},
          {uname:"john",city:"sec"}
      ]
  }
   render(){
    var loopdata=null
    loopdata=this.state.obj.map((userinfo)=>{
    return <tr><td>{userinfo.uname}</td><td>{userinfo.city}</td></tr>
    })
       return(
           <div>
             <table border="1">
      <th>username</th>
      <th>city</th>
      {loopdata}
             </table>

           </div>
       )
   }
}
export default cls1;