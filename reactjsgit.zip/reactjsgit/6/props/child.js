import React ,{Component} from "react"

class cls1 extends Component{
    constructor(props){
        super()
    }
    render(){
        return (
            <div>
    <h1>hiii my name is {this.props.name} and i am from {this.props.from}</h1>
                </div>
        )
    }
}
export default cls1;