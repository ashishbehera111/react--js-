import React,{Component} from "react";
import CHILD from "./child";

class cls2 extends Component{
    render(){
        return (
            <div>
<CHILD name="ashish" from="odisha"/>
            </div>
        )
    }
}
export default cls2;