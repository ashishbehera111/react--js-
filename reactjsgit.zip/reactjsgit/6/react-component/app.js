import React,{Component} from "react";
import ABCD from "./abcd/index";

class cls1 extends Component{
    render(){
        return (
            <div>
                welcome
                <ABCD/>
            </div>
            )
    }
}

export default cls1;