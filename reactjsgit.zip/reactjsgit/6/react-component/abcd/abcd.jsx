import "./abcd.css";
import React from "react";

function template() {
  return (
    <div className="abcd">
      <h1>abcd</h1>
    </div>
  );
};

export default template;
