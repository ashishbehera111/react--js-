import abcd from "./abcd";
export default abcd;
