import React    from "react";
import template from "./abcd.jsx";
import "./abcd.css"

class abcd extends React.Component {
  render() {
    return (
      <div>
        <h1 className="ashish">to react js</h1> 
      </div>
    )
  }
}

export default abcd;
