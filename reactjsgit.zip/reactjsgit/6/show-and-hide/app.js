import React,{Component} from "react";
import pic from "./article_mobile.jpg"

class cls1 extends Component{
    tmp="block"
    fun1=()=>{
        this.tmp="block"
        this.setState({})
    }
    fun2=()=>{
        this.tmp="none"
        this.setState({})
    }
    render(){
        return (
            <div>
                <input type="button"  value="show" onClick={this.fun1}></input>
                <input type="button"  value="hide" onClick={this.fun2}></input>
                <img style={{display:this.tmp}} src={pic} width="300px"></img>
            </div>
            )
    }
}

export default cls1;