import React,{Component} from "react";
class cls1 extends Component{
   fun1=()=>{
       localStorage.setItem("sno","100")
       alert("created")
   }
    render(){
        return (
          <div>
      <input type="button" value="click" onClick={this.fun1}></input>
           </div>
            )
    }
}

export default cls1;