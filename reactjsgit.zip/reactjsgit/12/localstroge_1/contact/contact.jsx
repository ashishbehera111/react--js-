import "./contact.css";
import React from "react";

function template() {
  var fun1=()=>{
    alert(localStorage.getItem("sno"))
  }
  return (
    <div className="contact">
    <input type="button" value="Getdata" onClick={fun1}></input>
    </div>
  );
};

export default template;
