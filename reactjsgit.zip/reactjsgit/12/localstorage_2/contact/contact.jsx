import "./contact.css";
import React from "react";

function template() {
  var fun1=()=>{
    var x=(localStorage.getItem("data"))
    var ob=JSON.parse(x)
    alert(ob.uname)
    alert(ob.city)
  }
  return (
    <div className="contact">
    <input type="button" value="Getdata" onClick={fun1}></input>
    </div>
  );
};

export default template;
