import React,{Component} from "react";
class cls1 extends Component{
   fun1=()=>{
      var obj={uname:"scott" ,city:"hyd"}
      localStorage.setItem("data",JSON.stringify(obj))
      alert("created")
   }
    render(){
        return (
          <div>
      <input type="button" value="click" onClick={this.fun1}></input>
           </div>
            )
    }
}

export default cls1;