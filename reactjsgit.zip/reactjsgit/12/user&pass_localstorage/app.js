import React from 'react'
class app extends React.Component{
    state={
        uname:"",
        pwd:""
    }
chk1
   funlogin=()=>{
    if(this.chk1 == true)
    {
        localStorage.setItem(this.state.uname,
            this.state.pwd)
    }
   }
   funchange1=(t)=>{
    this.setState({
        uname:t.target.value
    })
   }
   funchange2=(t)=>{
    this.setState({
        pwd:t.target.value
    })
   }
   fun2=(t)=>{
    var str=localStorage.getItem(t.target.value)
    this.setState({
        pwd:str
    })    
   }
   funcheck=(t)=>{
    this.chk1=t.target.checked
}
    render(){    
    return(
        <span>
            <input type="text" placeholder="Username"
             value={this.state.uname} 
             onBlur={this.fun2.bind(this)} 
             onChange={this.funchange1.bind(this)}></input>
            <br></br>
            <input type="password" placeholder="Password" 
            value={this.state.pwd} 
            onChange={this.funchange2.bind(this)}></input>
        <br>
        </br>
        <input type="checkbox" 
        onChange={this.funcheck.bind(this)}></input>
        <input type="button" value="Login"
         onClick={this.funlogin}></input>
        </span>
    )
}
}
export default app