const express =require("express")
const cors =require("cors")
const Product=require("./model/product")
const mongoose = require("mongoose")


const app = express();

app.use(cors())


//connect to mongodb database 

mongoose.connect("mongodb+srv://ashish:khuljasimsim123@cluster0.owfcj.mongodb.net/ecommerce-7pm?retryWrites=true&w=majority",{

useNewUrlParser:true,
useUnifiedTopology:true,

},(err)=>{
    if(err)throw err;
    else{
        console.log("connection success")
    }
})
//create the rest api

app.get("/api/products",async(req,res)=>{
    const products= await Product.find();
    res.send(products);

})

app.listen(8080,()=>{
    console.log("server listning the port no 8080")
})
